package com.cg.mpa.dto;

public class Mobile {

	private long mobileId;
	private String mName;
	private double price;
	private int quantity;
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Mobile(long mobileId, String mName, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mName = mName;
		this.price = price;
		this.quantity = quantity;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mName=" + mName + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
}

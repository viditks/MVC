package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dbutil.DBUtil;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobileDaoImpl implements MobileDao {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement pst = null;
	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		List<Mobile> mlist = new ArrayList<Mobile>();
		con = DBUtil.getCon();
		try {
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			while(rs.next()) {
				Mobile m = new Mobile();
				
				m.setMobileId(rs.getLong("mobileid"));
				m.setmName(rs.getString("name"));
				m.setPrice(rs.getDouble("price"));
				m.setQuantity(rs.getInt("quantity"));
				
				mlist.add(m);
				
			}
			
		}
		catch (Exception e) {
			
			throw new MobileException("Mobile not found");
		}
		finally{
			try{
				con.close();
				rs.close();
				st.close();
			}
			catch (Exception e) {
				
				throw new MobileException("Problem in fetching mobiles");
			}
		}
		
		return mlist;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException {
		con = DBUtil.getCon();
		Mobile m = null;
		try {
			pst = con.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1, mid);
			rs = pst.executeQuery();
			
			if(rs.next()) {
				
				m = new Mobile();
				m.setMobileId(rs.getLong("mobileid"));
				m.setmName(rs.getString("name"));
				m.setPrice(rs.getDouble("price"));
				m.setQuantity(rs.getInt("quantity"));
				
			}
			
			
		}
		catch (Exception e) {
			
			throw new MobileException("Mobile not found");
		}
		finally{
			try{
				con.close();
				rs.close();
				pst.close();
			}
			catch (Exception e) {
				
				throw new MobileException("Problem in fetching mobile");
			}
		}
		return m;
	}
	private long generatePurchaseId() throws MobileException{
		long pid = 0;
		con = DBUtil.getCon();
		try {
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			
			rs.next();
			pid = rs.getLong(1);
		} 
		catch (Exception e) {
			 throw new MobileException("Problem in generating purchase id" + " " + e.getMessage());
		}
		return pid;
		
	}
	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException {
		con = DBUtil.getCon();
		long dataInserted;
		pDetails.setPurchaseid(generatePurchaseId());
		try {
			pst = con.prepareStatement(QueryMapper.INSERT_QUERY);
			
			pst.setLong(1, pDetails.getPurchaseid());
			pst.setString(2, pDetails.getCname());
			pst.setString(3, pDetails.getMailid());
			pst.setLong(4, pDetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setLong(6, pDetails.getMobileid());
			dataInserted = 
					pst.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new MobileException("Problem in inserting purchase details");
		}
		return dataInserted;
	}
	
	

}

package com.cg.mpa.dao;

public interface QueryMapper {

	String SELECT_ALL_MOBILES = "SELECT * FROM MOBILES";
	String SELECT_MOBILE = "SELECT * FROM MOBILES WHERE mobileid=?";
	String SELECT_SEQUENCE = "SELECT purchase_seq.NEXTVAL from DUAL";
	String INSERT_QUERY = "INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
}
